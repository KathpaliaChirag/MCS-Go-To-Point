// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IProofVerifier {
    function verify(bytes calldata proof, bytes32 publicInput) external view returns (bool);
}

contract Rollup {
    enum BatchType {
        Single,
        Multi
    }

    struct Batch {
        bytes32 stateRoot;
        bytes32 parentRoot;
        uint256 timestamp;
        bool finalized;
        bool challenged;
        BatchType batchType;
    }

    uint256 public constant MAX_BATCH_TX = 5;

    struct L2Tx {
        address from;
        address to;
        uint256 amount;
        uint256 nonce;
        uint8 v;
        bytes32 r;
        bytes32 s;
    }

    struct TxProofData {
        uint256 senderBalanceBefore;
        uint256 senderNonceBefore;
        bytes32[] senderProof;
        uint256 senderIndex;
        uint256 receiverBalanceBefore;
        uint256 receiverNonceBefore;
        bytes32[] receiverProof;
        uint256 receiverIndex;
    }

    bytes32 public currentStateRoot;
    bytes32 public latestFinalizedRoot;
    uint256 public sequencerStake;
    address public sequencer;
    address public zkVerifier;
    uint256 public challengeWindow;
    mapping(uint256 => Batch) public batches;
    uint256 public batchCount;
    mapping(address => uint256) public totalWithdrawn;

    event Deposit(address indexed user, uint256 amount);
    event BatchSubmitted(uint256 indexed batchId, bytes32 stateRoot);
    event BatchChallenged(uint256 indexed batchId, address challenger);
    event BatchFinalized(uint256 indexed batchId);
    event Withdrawal(address indexed user, uint256 amount, uint256 indexed batchId);
    event ZkVerifierUpdated(address indexed verifier);
    event StakeToppedUp(address indexed from, uint256 amount, uint256 newStake);

    constructor(address _sequencer, uint256 _challengeWindow) payable {
        sequencer = _sequencer;
        challengeWindow = _challengeWindow;
        if (msg.value > 0) {
            sequencerStake = msg.value;
        }
    }

    function deposit() external payable {
        revert("NotImplemented");
    }

    function submitBatch(bytes32 newRoot) external {
        newRoot;
        revert("NotImplemented");
    }

    function submitMultiBatch(bytes32 newRoot) external {
        newRoot;
        revert("NotImplemented");
    }

    function setZkVerifier(address verifier) external {
        verifier;
        revert("NotImplemented");
    }

    function topUpStake() external payable {
        revert("NotImplemented");
    }

    function challengeBatch(
        uint256 batchId,
        bytes32 prevRoot,
        address from,
        address to,
        uint256 amount,
        uint256 nonce,
        uint8 v,
        bytes32 r,
        bytes32 s,
        uint256 senderBalance,
        bytes32[] calldata senderProof,
        uint256 senderIndex,
        uint256 receiverBalance,
        uint256 receiverNonce,
        bytes32[] calldata receiverProof,
        uint256 receiverIndex,
        bytes32 expectedNewRoot
    ) external {
        batchId; prevRoot; from; to; amount; nonce; v; r; s;
        senderBalance; senderProof; senderIndex; receiverBalance; receiverNonce; receiverProof; receiverIndex; expectedNewRoot;
        revert("NotImplemented");
    }

    function challengeMultiBatch(
        uint256 batchId,
        bytes32 prevRoot,
        L2Tx[] calldata txs,
        TxProofData[] calldata proofs,
        bytes32 submittedRoot
    ) external {
        batchId; prevRoot; txs; proofs; submittedRoot;
        revert("NotImplemented");
    }

    function challengeBatchZK(
        uint256 batchId,
        bytes32 prevRoot,
        bytes32 submittedRoot,
        bytes calldata proof,
        bytes32 publicInput
    ) external {
        batchId; prevRoot; submittedRoot; proof; publicInput;
        revert("NotImplemented");
    }

    function challengeMultiBatchZK(
        uint256 batchId,
        bytes32 prevRoot,
        bytes32 submittedRoot,
        bytes calldata proof,
        bytes32 publicInput
    ) external {
        batchId; prevRoot; submittedRoot; proof; publicInput;
        revert("NotImplemented");
    }

    function finalizeBatch(uint256 batchId) external {
        batchId;
        revert("NotImplemented");
    }

    function withdraw(
        uint256 batchId,
        uint256 balance,
        uint256 nonce,
        bytes32[] calldata proof,
        uint256 index
    ) external {
        batchId; balance; nonce; proof; index;
        revert("NotImplemented");
    }

    function verifyProofView(
        bytes32 leafHash_,
        bytes32[] calldata proof,
        bytes32 root,
        uint256 index
    ) external pure returns (bool) {
        leafHash_; proof; root; index;
        revert("NotImplemented");
    }

    function applyProofUpdateView(
        uint256 index,
        bytes32 newLeaf,
        bytes32[] calldata proof
    ) external pure returns (bytes32) {
        index; newLeaf; proof;
        revert("NotImplemented");
    }

    function rootAfterFirstNTxs(
        bytes32 prevRoot,
        L2Tx[] calldata txs,
        TxProofData[] calldata proofs,
        uint256 n
    ) external pure returns (bytes32) {
        prevRoot; txs; proofs; n;
        revert("NotImplemented");
    }

    function latestSubmittedRoot() external view returns (bytes32) {
        revert("NotImplemented");
    }

    receive() external payable {}
}
