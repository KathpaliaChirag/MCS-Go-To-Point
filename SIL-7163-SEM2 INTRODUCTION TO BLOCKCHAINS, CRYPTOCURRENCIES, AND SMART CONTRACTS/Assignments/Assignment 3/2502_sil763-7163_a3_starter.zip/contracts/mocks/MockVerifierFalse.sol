// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract MockVerifierFalse {
    function verify(bytes calldata, bytes32) external pure returns (bool) {
        return false;
    }
}
