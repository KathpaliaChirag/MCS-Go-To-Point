// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract MockVerifierTrue {
    function verify(bytes calldata, bytes32) external pure returns (bool) {
        return true;
    }
}
