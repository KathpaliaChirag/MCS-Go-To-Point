import { expect } from "chai";
import { ethers } from "hardhat";
import { StateEngine, buildMultiFraudProof, type L2Transaction } from "../lib/state";

describe("Rollup (Open Suite)", function () {
  const CHALLENGE_WINDOW = 60;
  let rollup: Awaited<ReturnType<typeof deployRollup>>;
  let sequencer: { address: string; signer: Awaited<ReturnType<typeof ethers.getSigners>>[0] };
  let alice: { address: string; signer: Awaited<ReturnType<typeof ethers.getSigners>>[0] };
  let bob: { address: string; signer: Awaited<ReturnType<typeof ethers.getSigners>>[0] };

  async function deployRollup() {
    const [seq] = await ethers.getSigners();
    const Rollup = await ethers.getContractFactory("Rollup");
    const r = await Rollup.connect(seq).deploy(seq.address, CHALLENGE_WINDOW, {
      value: ethers.parseEther("1"),
    });
    await r.waitForDeployment();
    return r;
  }

  beforeEach(async function () {
    const signers = await ethers.getSigners();
    sequencer = { address: signers[0].address, signer: signers[0] };
    alice = { address: signers[1].address, signer: signers[1] };
    bob = { address: signers[2].address, signer: signers[2] };
    rollup = await deployRollup();
  });

  function zkInput(batchId: bigint, prevRoot: string, submittedRoot: string, isMulti: boolean): string {
    return ethers.keccak256(
      ethers.AbiCoder.defaultAbiCoder().encode(
        ["uint256", "bytes32", "bytes32", "bool"],
        [batchId, ethers.zeroPadValue(prevRoot, 32), ethers.zeroPadValue(submittedRoot, 32), isMulti]
      )
    );
  }

  async function signL2Tx(
    from: { address: string; signer: { signMessage: (msg: Uint8Array) => Promise<string> } },
    to: string,
    amount: bigint,
    nonce: number
  ): Promise<L2Transaction> {
    const messageHash = ethers.keccak256(
      ethers.AbiCoder.defaultAbiCoder().encode(
        ["address", "address", "uint256", "uint256"],
        [from.address, to, amount, nonce]
      )
    );
    const sigHex = await from.signer.signMessage(ethers.getBytes(messageHash));
    return { from: from.address, to, amount, nonce, signature: sigHex };
  }

  it("deploys with sequencer stake 1 ETH", async function () {
    expect(await rollup.sequencer()).to.eq(sequencer.address);
    expect(await rollup.sequencerStake()).to.eq(ethers.parseEther("1"));
  });

  it("accepts deposits and emits Deposit", async function () {
    await expect(rollup.connect(alice.signer).deposit({ value: ethers.parseEther("1") }))
      .to.emit(rollup, "Deposit")
      .withArgs(alice.address, ethers.parseEther("1"));
  });

  it("sequencer can submit batch and currentStateRoot updates", async function () {
    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("10"));
    const root = state.computeStateRoot();
    await rollup.connect(sequencer.signer).submitBatch(ethers.zeroPadValue(root, 32));
    expect(await rollup.currentStateRoot()).to.eq(ethers.zeroPadValue(root, 32));
  });

  it("challenge succeeds when sequencer submitted wrong root", async function () {
    const stateBefore = new StateEngine();
    stateBefore.addDeposit(alice.address, ethers.parseEther("10"));
    stateBefore.addDeposit(bob.address, ethers.parseEther("5"));
    const amount = ethers.parseEther("3");
    const l2Tx: L2Transaction = {
      from: alice.address,
      to: bob.address,
      amount,
      nonce: 0,
      signature: await alice.signer.signMessage(
        ethers.getBytes(
          ethers.keccak256(
            ethers.AbiCoder.defaultAbiCoder().encode(
              ["address", "address", "uint256", "uint256"],
              [alice.address, bob.address, amount, 0]
            )
          )
        )
      ),
    };
    const { prevRoot, proofs } = buildMultiFraudProof(stateBefore, [l2Tx]);
    const sig = ethers.Signature.from(l2Tx.signature);
    const wrongRoot = prevRoot;

    await rollup.connect(sequencer.signer).submitBatch(ethers.zeroPadValue(prevRoot, 32));
    await rollup.connect(sequencer.signer).submitBatch(ethers.zeroPadValue(wrongRoot, 32));
    const batchId = (await rollup.batchCount()) - 1n;
    const p = proofs[0]!;

    await rollup.connect((await ethers.getSigners())[3]).challengeBatch(
      batchId,
      ethers.zeroPadValue(prevRoot, 32),
      alice.address,
      bob.address,
      amount,
      BigInt(p.senderNonceBefore),
      sig.v,
      sig.r,
      sig.s,
      p.senderBalanceBefore,
      p.senderProof.map((h) => ethers.zeroPadValue(h, 32)),
      p.senderIndex,
      p.receiverBalanceBefore,
      p.receiverNonceBefore,
      p.receiverProof.map((h) => ethers.zeroPadValue(h, 32)),
      p.receiverIndex,
      ethers.zeroPadValue(wrongRoot, 32)
    );
  });

  it("finalizeBatch requires challenge window passed", async function () {
    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("1"));
    const root = state.computeStateRoot();
    await rollup.connect(sequencer.signer).submitBatch(ethers.zeroPadValue(root, 32));
    const batchId = (await rollup.batchCount()) - 1n;
    await expect(rollup.finalizeBatch(batchId)).to.be.revertedWith("challenge window not passed");
  });

  it("finalizes after challenge window and allows withdrawal", async function () {
    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("2"));
    await rollup.connect(alice.signer).deposit({ value: ethers.parseEther("2") });
    const root = state.computeStateRoot();
    await rollup.connect(sequencer.signer).submitBatch(ethers.zeroPadValue(root, 32));
    const batchId = (await rollup.batchCount()) - 1n;
    await ethers.provider.send("evm_increaseTime", [CHALLENGE_WINDOW + 1]);
    await ethers.provider.send("evm_mine", []);
    await rollup.finalizeBatch(batchId);

    const { getProof, sortedAddresses } = state.buildMerkle();
    const idx = sortedAddresses.indexOf(alice.address);
    const proof = getProof(idx).map((p) => ethers.zeroPadValue(p, 32));
    await rollup.connect(alice.signer).withdraw(batchId, state.getBalance(alice.address), state.getNonce(alice.address), proof, idx);
  });

  it("single-batch zk challenge works with verifier=true", async function () {
    const [seq, challenger] = await ethers.getSigners();
    const localRollup = await deployRollup();
    const TrueVerifier = await ethers.getContractFactory("MockVerifierTrue");
    const verifier = await TrueVerifier.deploy();
    await verifier.waitForDeployment();
    await localRollup.connect(seq).setZkVerifier(await verifier.getAddress());

    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("3"));
    const root = state.computeStateRoot();
    await localRollup.connect(seq).submitBatch(ethers.zeroPadValue(root, 32));
    const batchId = (await localRollup.batchCount()) - 1n;
    await localRollup.connect(challenger).challengeBatchZK(
      batchId,
      ethers.zeroPadValue(ethers.ZeroHash, 32),
      ethers.zeroPadValue(root, 32),
      "0x11",
      zkInput(batchId, ethers.ZeroHash, root, false)
    );
  });

  it("single-batch zk challenge reverts with verifier=false", async function () {
    const [seq, challenger] = await ethers.getSigners();
    const localRollup = await deployRollup();
    const FalseVerifier = await ethers.getContractFactory("MockVerifierFalse");
    const verifier = await FalseVerifier.deploy();
    await verifier.waitForDeployment();
    await localRollup.connect(seq).setZkVerifier(await verifier.getAddress());

    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("3"));
    const root = state.computeStateRoot();
    await localRollup.connect(seq).submitBatch(ethers.zeroPadValue(root, 32));
    const batchId = (await localRollup.batchCount()) - 1n;
    await expect(
      localRollup.connect(challenger).challengeBatchZK(
        batchId,
        ethers.zeroPadValue(ethers.ZeroHash, 32),
        ethers.zeroPadValue(root, 32),
        "0x11",
        zkInput(batchId, ethers.ZeroHash, root, false)
      )
    ).to.be.revertedWith("zk verify failed");
  });

  it("Fraud in tx #2: wrong submitted root, challengeMultiBatch succeeds", async function () {
    const localRollup = await deployRollup();
    const prevState = new StateEngine();
    prevState.addDeposit(alice.address, ethers.parseEther("20"));
    prevState.addDeposit(bob.address, ethers.parseEther("10"));
    const tx1 = await signL2Tx(alice, bob.address, ethers.parseEther("3"), 0);
    const tx2 = await signL2Tx(bob, alice.address, ethers.parseEther("1"), 0);
    const { prevRoot, txs, proofs } = buildMultiFraudProof(prevState, [tx1, tx2]);
    const wrongRoot = prevRoot;

    await localRollup.connect(sequencer.signer).submitMultiBatch(ethers.zeroPadValue(prevRoot, 32));
    await localRollup.connect(sequencer.signer).submitMultiBatch(ethers.zeroPadValue(wrongRoot, 32));
    const batchId = (await localRollup.batchCount()) - 1n;

    await localRollup.connect((await ethers.getSigners())[4]).challengeMultiBatch(
      batchId,
      ethers.zeroPadValue(prevRoot, 32),
      txs.map((t) => ({ from: t.from, to: t.to, amount: t.amount, nonce: t.nonce, v: t.v, r: t.r, s: t.s })),
      proofs.map((p) => ({
        senderBalanceBefore: p.senderBalanceBefore,
        senderNonceBefore: p.senderNonceBefore,
        senderProof: p.senderProof.map((h) => ethers.zeroPadValue(h, 32)),
        senderIndex: p.senderIndex,
        receiverBalanceBefore: p.receiverBalanceBefore,
        receiverNonceBefore: p.receiverNonceBefore,
        receiverProof: p.receiverProof.map((h) => ethers.zeroPadValue(h, 32)),
        receiverIndex: p.receiverIndex,
      })),
      ethers.zeroPadValue(wrongRoot, 32)
    );
  });

  it("cannot finalize a challenged batch", async function () {
    const [seq, challenger] = await ethers.getSigners();
    const localRollup = await deployRollup();
    const TrueVerifier = await ethers.getContractFactory("MockVerifierTrue");
    const verifier = await TrueVerifier.deploy();
    await verifier.waitForDeployment();
    await localRollup.connect(seq).setZkVerifier(await verifier.getAddress());

    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("1"));
    const root = state.computeStateRoot();
    await localRollup.connect(seq).submitBatch(ethers.zeroPadValue(root, 32));
    const batchId = (await localRollup.batchCount()) - 1n;

    await localRollup.connect(challenger).challengeBatchZK(
      batchId,
      ethers.zeroPadValue(ethers.ZeroHash, 32),
      ethers.zeroPadValue(root, 32),
      "0x12",
      zkInput(batchId, ethers.ZeroHash, root, false)
    );

    await ethers.provider.send("evm_increaseTime", [CHALLENGE_WINDOW + 1]);
    await ethers.provider.send("evm_mine", []);
    await expect(localRollup.finalizeBatch(batchId)).to.be.revertedWith("batch was challenged");
  });

  it("rejects withdrawal with wrong nonce even if balance matches", async function () {
    const state = new StateEngine();
    state.addDeposit(alice.address, ethers.parseEther("2"));
    const root = state.computeStateRoot();
    await rollup.connect(sequencer.signer).submitBatch(ethers.zeroPadValue(root, 32));
    const batchId = (await rollup.batchCount()) - 1n;
    await ethers.provider.send("evm_increaseTime", [CHALLENGE_WINDOW + 1]);
    await ethers.provider.send("evm_mine", []);
    await rollup.finalizeBatch(batchId);

    const { getProof, sortedAddresses } = state.buildMerkle();
    const idx = sortedAddresses.indexOf(alice.address);
    const proof = getProof(idx).map((p) => ethers.zeroPadValue(p, 32));

    await expect(
      rollup.connect(alice.signer).withdraw(batchId, state.getBalance(alice.address), state.getNonce(alice.address) + 1, proof, idx)
    ).to.be.revertedWith("invalid withdrawal proof");
  });
});
