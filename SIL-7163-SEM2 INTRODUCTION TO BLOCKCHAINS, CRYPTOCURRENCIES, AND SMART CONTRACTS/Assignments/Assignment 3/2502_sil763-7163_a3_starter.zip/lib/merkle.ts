export type LeafInput = Buffer | Uint8Array | string;

export function verifyProof(leafHash: string, proof: string[], root: string, index?: number): boolean {
  void leafHash;
  void proof;
  void root;
  void index;
  throw new Error("NotImplemented");
}

export function applyProofUpdate(
  root: string,
  index: number,
  newLeaf: string,
  proof: string[],
  oldLeaf?: string
): string {
  void root;
  void index;
  void newLeaf;
  void proof;
  void oldLeaf;
  throw new Error("NotImplemented");
}

export function buildTree(leaves: LeafInput[]): {
  root: string;
  getProof: (index: number) => string[];
  getLeafHash: (index: number) => string;
} {
  void leaves;
  throw new Error("NotImplemented");
}
