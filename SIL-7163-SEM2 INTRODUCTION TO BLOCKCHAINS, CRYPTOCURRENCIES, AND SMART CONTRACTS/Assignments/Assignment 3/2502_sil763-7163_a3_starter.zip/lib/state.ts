export interface L2Transaction {
  from: string;
  to: string;
  amount: bigint;
  nonce: number;
  signature: string;
}

export function leafHash(address: string, balance: bigint, nonce: number): string {
  void address;
  void balance;
  void nonce;
  throw new Error("NotImplemented");
}

export class StateEngine {
  getBalance(address: string): bigint {
    void address;
    throw new Error("NotImplemented");
  }

  getNonce(address: string): number {
    void address;
    throw new Error("NotImplemented");
  }

  applyTransaction(tx: L2Transaction): void {
    void tx;
    throw new Error("NotImplemented");
  }

  computeStateRoot(): string {
    throw new Error("NotImplemented");
  }

  addDeposit(address: string, amount: bigint): void {
    void address;
    void amount;
    throw new Error("NotImplemented");
  }

  buildMerkle(): {
    root: string;
    getProof: (index: number) => string[];
    getLeafHash: (index: number) => string;
    sortedAddresses: string[];
  } {
    throw new Error("NotImplemented");
  }

}

export interface TxProofDataForContract {
  senderBalanceBefore: bigint;
  senderNonceBefore: number;
  senderProof: string[];
  senderIndex: number;
  receiverBalanceBefore: bigint;
  receiverNonceBefore: number;
  receiverProof: string[];
  receiverIndex: number;
}

export interface L2TxForContract {
  from: string;
  to: string;
  amount: bigint;
  nonce: number;
  v: number;
  r: string;
  s: string;
}

export function buildMultiFraudProof(
  prevState: StateEngine,
  txArray: L2Transaction[]
): {
  prevRoot: string;
  txs: L2TxForContract[];
  proofs: TxProofDataForContract[];
  finalRoot: string;
} {
  void prevState;
  void txArray;
  throw new Error("NotImplemented");
}
