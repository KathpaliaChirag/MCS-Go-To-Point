## Rollup Assignment Starter

This directory contains a minimal starter template.

### Setup

```bash
npm install
npm run compile
npm test
```

