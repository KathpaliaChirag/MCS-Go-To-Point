"""
Public tests for Assignment 2: load sample_transactions.json and run verifier.
Run from A2_UTXO_Script with submission on PYTHONPATH, e.g.:
  PYTHONPATH=starter_code python tests/public_tests.py
  PYTHONPATH=solution python tests/public_tests.py
"""
import os
import sys
import json

# Ensure we can import verifier from submission (starter_code or solution)
ROOT = os.path.join(os.path.dirname(__file__), "..")
SUBMISSION = os.environ.get("PYTHONPATH", os.path.join(ROOT, "starter_code"))
if os.path.basename(SUBMISSION.rstrip("/")) == "solution":
    # Load solution as a package so relative imports work
    if ROOT not in sys.path:
        sys.path.insert(0, ROOT)
    from solution import verifier
else:
    if SUBMISSION not in sys.path:
        sys.path.insert(0, SUBMISSION)
    import verifier


def build_utxo_from_genesis(genesis_txid: str, genesis_outputs: list) -> dict:
    utxo_set = {}
    for vout, out in enumerate(genesis_outputs):
        utxo_set[(genesis_txid, vout)] = {
            "value": out["value"],
            "script_pubkey": list(out["script_pubkey"]),
        }
    return utxo_set


def run_tests():
    base = os.path.dirname(__file__)
    path = os.path.join(base, "sample_transactions.json")
    with open(path) as f:
        data = json.load(f)

    genesis_txid = data["genesis_txid"]
    genesis_outputs = data["genesis_outputs"]
    cases = data["transactions"]
    passed = 0
    failed = []

    for entry in cases:
        name = entry["name"]
        tx = entry["tx"]
        expected = entry["expected"]
        utxo_set = build_utxo_from_genesis(genesis_txid, genesis_outputs)
        try:
            result = verifier.verify_transaction(tx, utxo_set)
        except Exception as e:
            print(f"  ERROR: {name} raised exception: {e}")
            failed.append(name)
            continue
        if result == expected:
            passed += 1
            print(f"  PASS: {name}")
        else:
            failed.append(name)
            print(f"  FAIL: {name} (expected {expected}, got {result})")

    # Double-spend: same tx twice
    utxo_set = build_utxo_from_genesis(genesis_txid, genesis_outputs)
    tx_first = next((c["tx"] for c in cases if c["expected"]), None)
    if tx_first is None:
        print("ERROR: no valid transaction found for double_spend test")
        return False
    try:
        r1 = verifier.verify_transaction(tx_first, utxo_set)
    except Exception as e:
        print(f"  ERROR: double_spend raised exception: {e}")
        failed.append("double_spend")
        r1 = None
    if r1 is not None:
        try:
            r2 = verifier.verify_transaction(tx_first, utxo_set)
        except Exception as e:
            print(f"  ERROR: double_spend raised exception: {e}")
            failed.append("double_spend")
        else:
            if r1 and not r2:
                passed += 1
                print("  PASS: double_spend")
            else:
                failed.append("double_spend")
                print(f"  FAIL: double_spend (expected True then False, got {r1} then {r2})")

    total = len(cases) + 1
    print(f"\n{passed}/{total} passed")
    return len(failed) == 0


if __name__ == "__main__":
    ok = run_tests()
    sys.exit(0 if ok else 1)
