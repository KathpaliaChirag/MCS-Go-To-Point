"""
Generate sample_transactions.json using the solution implementation.
Run from A2_UTXO_Script: python tests/generate_sample.py
"""
import sys
import json
import os

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, ROOT)

from ecdsa import SigningKey, SECP256k1
from ecdsa.util import sigencode_string

from solution.transaction import get_signing_message
from solution.crypto import hash160

GENESIS_TXID = "0" * 64


def make_p2pkh_script_pubkey(pubkey_bytes: bytes) -> list:
    h = hash160(pubkey_bytes).hex()
    return ["OP_DUP", "OP_HASH160", h, "OP_EQUALVERIFY", "OP_CHECKSIG"]


def make_signed_p2pkh_input(prev_txid: str, prev_vout: int, sk: SigningKey, tx: dict, input_index: int, script_pubkey: list) -> dict:
    msg = get_signing_message(tx, input_index, script_pubkey)
    sig = sk.sign_digest(msg, sigencode=sigencode_string)
    vk = sk.get_verifying_key()
    pubkey = vk.to_string()
    return {
        "txid": prev_txid,
        "vout": prev_vout,
        "script_sig": [sig.hex(), pubkey.hex()],
    }


def main():
    # Single-owner P2PKH key
    sk = SigningKey.generate(curve=SECP256k1)
    vk = sk.get_verifying_key()
    pubkey = vk.to_string()
    script_pubkey = make_p2pkh_script_pubkey(pubkey)

    # 2-of-3 multisig keys
    sk1 = SigningKey.generate(curve=SECP256k1)
    sk2 = SigningKey.generate(curve=SECP256k1)
    sk3 = SigningKey.generate(curve=SECP256k1)
    vk1, vk2, vk3 = sk1.get_verifying_key(), sk2.get_verifying_key(), sk3.get_verifying_key()
    pubkeys_hex = [vk1.to_string().hex(), vk2.to_string().hex(), vk3.to_string().hex()]

    # Locking script for 2-of-3 multisig UTXO matches the assignment spec:
    # ["2", pub1, pub2, pub3, "3", "OP_CHECKMULTISIG"]
    multisig_script_pubkey = [
        "2",
        pubkeys_hex[0],
        pubkeys_hex[1],
        pubkeys_hex[2],
        "3",
        "OP_CHECKMULTISIG",
    ]

    # Genesis: two outputs — 0 = P2PKH, 1 = 2-of-3 multisig
    genesis_outputs = [
        {"value": 100_000, "script_pubkey": script_pubkey},
        {"value": 50_000, "script_pubkey": multisig_script_pubkey},
    ]

    # ---- Valid P2PKH (spends genesis output 0)
    tx_valid = {
        "inputs": [{"txid": GENESIS_TXID, "vout": 0, "script_sig": []}],
        "outputs": [{"value": 90_000, "script_pubkey": script_pubkey}],
    }
    tx_valid["inputs"][0] = make_signed_p2pkh_input(
        GENESIS_TXID, 0, sk, tx_valid, 0, script_pubkey
    )

    # ---- Invalid signature (spends genesis 0 with wrong key)
    sk_wrong = SigningKey.generate(curve=SECP256k1)
    tx_bad_sig = {
        "inputs": [{"txid": GENESIS_TXID, "vout": 0, "script_sig": []}],
        "outputs": [{"value": 50_000, "script_pubkey": script_pubkey}],
    }
    tx_bad_sig["inputs"][0] = make_signed_p2pkh_input(
        GENESIS_TXID, 0, sk_wrong, tx_bad_sig, 0, script_pubkey
    )

    # ---- Invalid fee (outputs > inputs)
    tx_bad_fee_body = {
        "inputs": [{"txid": GENESIS_TXID, "vout": 0, "script_sig": []}],
        "outputs": [{"value": 200_000, "script_pubkey": script_pubkey}],
    }
    tx_bad_fee_body["inputs"][0] = make_signed_p2pkh_input(
        GENESIS_TXID, 0, sk, tx_bad_fee_body, 0, script_pubkey
    )
    tx_bad_fee = tx_bad_fee_body

    # ---- 2-of-3 multisig (spends genesis output 1)
    tx_multisig = {
        "inputs": [{"txid": GENESIS_TXID, "vout": 1, "script_sig": []}],
        "outputs": [{"value": 40_000, "script_pubkey": script_pubkey}],
    }
    # Signing message uses the full multisig locking script
    msg_m = get_signing_message(tx_multisig, 0, multisig_script_pubkey)
    sig1 = sk1.sign_digest(msg_m, sigencode=sigencode_string)
    sig2 = sk2.sign_digest(msg_m, sigencode=sigencode_string)
    # scriptSig contains only signatures in order: [sig1, sig2]
    tx_multisig["inputs"][0]["script_sig"] = [
        sig1.hex(),
        sig2.hex(),
    ]

    out = {
        "genesis_txid": GENESIS_TXID,
        "genesis_outputs": genesis_outputs,
        "transactions": [
            {"tx": tx_valid, "expected": True, "name": "valid_p2pkh"},
            {"tx": tx_bad_sig, "expected": False, "name": "invalid_signature"},
            {"tx": tx_bad_fee, "expected": False, "name": "invalid_fee"},
            {"tx": tx_multisig, "expected": True, "name": "valid_multisig"},
        ],
    }

    out_path = os.path.join(os.path.dirname(__file__), "sample_transactions.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print("Generated", out_path)


if __name__ == "__main__":
    main()
