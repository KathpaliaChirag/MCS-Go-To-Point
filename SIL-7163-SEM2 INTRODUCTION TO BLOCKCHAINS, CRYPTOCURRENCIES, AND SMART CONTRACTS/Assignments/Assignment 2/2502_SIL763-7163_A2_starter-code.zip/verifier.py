"""
Main entry: verify a transaction and update UTXO set.
"""

# from utxo import get_output, spend_output, add_output
# from script import execute_script
# from transaction import tx_id, get_signing_message


def verify_transaction(tx: dict, utxo_set: dict) -> bool:
    """
    Validate tx against utxo_set.

    Validation logic (see the assignment instructions):
    - Check tx has at least one input and one output.
    - Check all inputs exist and are unspent (no double-spend).
    - Check no duplicate (txid, vout) in inputs.
    - Check fee rule: sum(input values) >= sum(output values).
    - For each input, compute signing message, then run script_sig + script_pubkey;
      script execution must succeed and end with a single true value.

    Atomicity requirement:
    - You MUST NOT mutate utxo_set while validating.
    - Only after all checks pass should you:
        * remove spent outputs from utxo_set, and
        * add new outputs for this tx.
    - If validation fails, utxo_set must remain unchanged.
    """
    # TODO: implement according to the rules above and the assignment instructions
    raise NotImplementedError
