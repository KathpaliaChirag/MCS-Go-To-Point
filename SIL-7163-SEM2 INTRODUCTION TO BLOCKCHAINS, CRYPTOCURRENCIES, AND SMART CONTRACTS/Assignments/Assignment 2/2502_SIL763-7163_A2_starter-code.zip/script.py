"""
Stack-based script interpreter.

Execute script_sig first, then script_pubkey.
`message` is the signing message for OP_CHECKSIG / OP_CHECKMULTISIG.

Supported opcodes (all required):
  OP_DUP
  OP_HASH160
  OP_EQUAL
  OP_EQUALVERIFY
  OP_CHECKSIG
  OP_VERIFY
  OP_CHECKMULTISIG

Data encoding rules (see the assignment instructions):
- Script elements are either:
  * One of the opcodes above, OR
  * Hex-encoded strings representing raw bytes (signatures, pubkeys, hashes), OR
  * Small Python ints (only for m and n in multisig).
- Non-opcode strings MUST be treated as hex; do NOT guess ASCII.
"""

# Import crypto for OP_HASH160, OP_CHECKSIG, OP_CHECKMULTISIG
# from crypto import hash160, verify_signature

OPCODES = {
    "OP_DUP",
    "OP_HASH160",
    "OP_EQUAL",
    "OP_EQUALVERIFY",
    "OP_CHECKSIG",
    "OP_VERIFY",
    "OP_CHECKMULTISIG",
}


def execute_script(script_sig: list, script_pubkey: list, message: bytes) -> bool:
    """
    Run script_sig then script_pubkey on a fresh stack.

    Failure semantics:
    - Any stack underflow or unknown opcode must cause immediate failure.
    - OP_VERIFY popping a false value must cause immediate failure.
    - OP_CHECKSIG / OP_CHECKMULTISIG push 1 (true) or 0 (false); they do not
      raise, but incorrect types should be treated as failure.

    Success:
    - After both scripts run, the stack must have exactly one item, and it
      must be true (non-zero int or non-empty bytes). Otherwise the script
      fails.
    """
    # TODO: implement according to the exact opcode semantics in the assignment instructions
    raise NotImplementedError


def _is_opcode(elem) -> bool:
    """True if elem is an opcode string (e.g. OP_DUP)."""
    return isinstance(elem, str) and elem.startswith("OP_")


def _to_bytes(elem: str) -> bytes:
    """
    Convert a non-opcode string element to bytes.
    MUST treat elem as hex; no ASCII guessing.
    """
    return bytes.fromhex(elem)
